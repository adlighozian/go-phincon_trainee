package helper

import "fmt"

func ShowMenuList() {
	fmt.Println("Menu")
	fmt.Println("1. List contact")
	fmt.Println("2. Add contact")
	fmt.Println("3. Update contact")
	fmt.Println("4. Delete contact")
	fmt.Println("5. Exit")
	fmt.Println()
	fmt.Println("Pilih menu")
}
