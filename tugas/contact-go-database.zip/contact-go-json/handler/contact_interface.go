package handler

type ContactHandler interface {
	List()
	Add()
	Update()
	Delete()
}
